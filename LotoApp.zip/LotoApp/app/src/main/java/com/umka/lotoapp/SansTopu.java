package com.umka.lotoapp;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SansTopu extends AppCompatActivity {
    private EditText[] numberInputs;
    private EditText bonusInput;
    private DatabaseHelper dbHelper;
    private LinearLayout animatedNumbersContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sans_topu);

        dbHelper = new DatabaseHelper(this);

        numberInputs = new EditText[]{
                findViewById(R.id.num1),
                findViewById(R.id.num2),
                findViewById(R.id.num3),
                findViewById(R.id.num4),
                findViewById(R.id.num5),
        };

        bonusInput = findViewById(R.id.bonusNumber);

        setupNumberValidation(numberInputs, 1, 34);
        setupNumberValidation(new EditText[]{bonusInput}, 1, 14);

        animatedNumbersContainer = findViewById(R.id.animatedNumbersContainer);

        Button btnAdd = findViewById(R.id.btnAddDraw);
        Button btnShow = findViewById(R.id.btnShowStats);

        btnAdd.setOnClickListener(v -> addDraw());
        btnShow.setOnClickListener(v -> showStatsAnimated());
    }

    private void setupNumberValidation(EditText[] inputs, int min, int max) {
        for (EditText et : inputs) {
            et.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
                @Override
                public void afterTextChanged(Editable s) {
                    String val = s.toString();
                    if (!val.isEmpty()) {
                        try {
                            int num = Integer.parseInt(val);
                            if (num < min || num > max) {
                                et.setError(min + " ile " + max + " arasında sayı girin");
                            } else {
                                et.setError(null);
                            }
                        } catch (NumberFormatException e) {
                            et.setError("Geçersiz sayı");
                        }
                    } else {
                        et.setError(null);
                    }
                }
            });
        }
    }

    private void addDraw() {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();

        for (int i = 0; i < numberInputs.length; i++) {
            String val = numberInputs[i].getText().toString().trim();
            if (val.isEmpty()) {
                Toast.makeText(this, "Tüm kutuları doldurun", Toast.LENGTH_SHORT).show();
                return;
            }
            int num;
            try {
                num = Integer.parseInt(val);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Geçersiz sayı", Toast.LENGTH_SHORT).show();
                return;
            }
            if (num < 1 || num > 34) {
                Toast.makeText(this, "1-34 arası sayı girin", Toast.LENGTH_SHORT).show();
                return;
            }
            values.put("n" + (i + 1), num);
        }

        String bonusVal = bonusInput.getText().toString().trim();
        if (bonusVal.isEmpty()) {
            Toast.makeText(this, "Bonus sayıyı girin", Toast.LENGTH_SHORT).show();
            return;
        }
        int bonusNum;
        try {
            bonusNum = Integer.parseInt(bonusVal);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Geçersiz bonus sayı", Toast.LENGTH_SHORT).show();
            return;
        }
        if (bonusNum < 1 || bonusNum > 14) {
            Toast.makeText(this, "1-14 arası bonus sayı girin", Toast.LENGTH_SHORT).show();
            return;
        }
        values.put("bonus", bonusNum);

        long id = db.insert("sans_topu", null, values);
        if (id > 0) {
            Toast.makeText(this, "Çekiliş kaydedildi", Toast.LENGTH_SHORT).show();
            for (EditText et : numberInputs) et.setText("");
            bonusInput.setText("");
        }
    }

    private void showStatsAnimated() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM sans_topu", null);

        Map<Integer, Integer> freqMain = new HashMap<>();
        Map<Integer, Integer> freqBonus = new HashMap<>();

        while (cursor.moveToNext()) {
            for (int i = 1; i <= 5; i++) {
                int colIndex = cursor.getColumnIndex("n" + i);
                if (colIndex != -1) {
                    int val = cursor.getInt(colIndex);
                    freqMain.put(val, freqMain.getOrDefault(val, 0) + 1);
                }
            }
            int bonusIndex = cursor.getColumnIndex("bonus");
            if (bonusIndex != -1) {
                int bonus = cursor.getInt(bonusIndex);
                freqBonus.put(bonus, freqBonus.getOrDefault(bonus, 0) + 1);
            }
        }
        cursor.close();

        List<Map.Entry<Integer, Integer>> sortedMain = new ArrayList<>(freqMain.entrySet());
        sortedMain.sort((a, b) -> b.getValue() - a.getValue());

        List<Map.Entry<Integer, Integer>> sortedBonus = new ArrayList<>(freqBonus.entrySet());
        sortedBonus.sort((a, b) -> b.getValue() - a.getValue());

        List<Integer> topNumbers = new ArrayList<>();

        for (int i = 0; i < Math.min(5, sortedMain.size()); i++) {
            topNumbers.add(sortedMain.get(i).getKey());
        }

        if (!sortedBonus.isEmpty()) {
            topNumbers.add(sortedBonus.get(0).getKey()); // bonus sayı en sonda
        }

        animateNumbers(topNumbers);
    }

    private void animateNumbers(List<Integer> numbers) {
        animatedNumbersContainer.removeAllViews();

        final int animationDuration = 600;

        TextView bigNumberView = new TextView(this);
        bigNumberView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 64);
        bigNumberView.setTextColor(Color.parseColor("#EF4444"));
        bigNumberView.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams bigParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        bigParams.setMarginEnd(24);
        bigNumberView.setLayoutParams(bigParams);

        animateNextNumber(numbers, 0, bigNumberView, animationDuration, () -> {
            // Tüm animasyonlar bittiğinde çalışacak kod (gerekirse eklenebilir)
        });
    }

    private void animateNextNumber(List<Integer> numbers, int index, TextView bigNumberView, int duration, Runnable onComplete) {
        if (index >= numbers.size()) {
            if (onComplete != null) {
                bigNumberView.postDelayed(onComplete, 400);
            }
            return;
        }

        int number = numbers.get(index);
        bigNumberView.setText(String.valueOf(number));
        bigNumberView.setScaleX(0f);
        bigNumberView.setScaleY(0f);
        bigNumberView.setAlpha(0f);
        bigNumberView.setTranslationY(0f);

        if (bigNumberView.getParent() == null) {
            animatedNumbersContainer.addView(bigNumberView, 0);
        }

        bigNumberView.animate()
                .scaleX(1f).scaleY(1f)
                .alpha(1f)
                .setDuration(duration)
                .setListener(null)
                .withEndAction(() -> {
                    TextView smallNumber = new TextView(this);
                    smallNumber.setText(String.valueOf(number));
                    smallNumber.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
                    smallNumber.setTextColor(Color.WHITE);
                    smallNumber.setGravity(Gravity.CENTER);
                    smallNumber.setBackgroundResource(R.drawable.rounded_background);
                    smallNumber.setPadding(24, 16, 24, 16);

                    LinearLayout.LayoutParams smallParams = new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT);
                    smallParams.setMargins(12, 0, 12, 0);
                    smallNumber.setLayoutParams(smallParams);
                    smallNumber.setAlpha(0f);

                    animatedNumbersContainer.addView(smallNumber);

                    ObjectAnimator fadeIn = ObjectAnimator.ofFloat(smallNumber, "alpha", 0f, 1f);
                    fadeIn.setDuration(300);

                    AnimatorSet moveAndShrink = new AnimatorSet();
                    ObjectAnimator scaleX = ObjectAnimator.ofFloat(bigNumberView, "scaleX", 0.3f);
                    ObjectAnimator scaleY = ObjectAnimator.ofFloat(bigNumberView, "scaleY", 0.3f);
                    ObjectAnimator alpha = ObjectAnimator.ofFloat(bigNumberView, "alpha", 0f);
                    ObjectAnimator translateY = ObjectAnimator.ofFloat(bigNumberView, "translationY", 0f, 60f);

                    moveAndShrink.playTogether(scaleX, scaleY, alpha, translateY);
                    moveAndShrink.setDuration(400);

                    moveAndShrink.addListener(new AnimatorListenerAdapter() {
                        @Override
                        public void onAnimationEnd(Animator animation) {
                            animatedNumbersContainer.removeView(bigNumberView);
                            animateNextNumber(numbers, index + 1, bigNumberView, duration, onComplete);
                        }
                    });

                    fadeIn.start();
                    moveAndShrink.start();
                })
                .start();
    }
}
