package com.umka.lotoapp;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OnNumara extends AppCompatActivity {
    private EditText[] numberInputs;
    private DatabaseHelper dbHelper;
    private LinearLayout animatedNumbersContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_on_numara);
        dbHelper = new DatabaseHelper(this);

        numberInputs = new EditText[]{
                findViewById(R.id.number1), findViewById(R.id.number2), findViewById(R.id.number3),
                findViewById(R.id.number4), findViewById(R.id.number5), findViewById(R.id.number6),
                findViewById(R.id.number7), findViewById(R.id.number8), findViewById(R.id.number9),
                findViewById(R.id.number10),
        };
        setupNumberValidation(numberInputs, 1, 80);
        animatedNumbersContainer = findViewById(R.id.animatedNumbersContainer);

        Button btnAdd = findViewById(R.id.btnAddDraw);
        Button btnShow = findViewById(R.id.btnShowStats);

        btnAdd.setOnClickListener(v -> addDraw());
        btnShow.setOnClickListener(v -> showMostCommonAnimated2());
    }

    private void setupNumberValidation(EditText[] inputs, int min, int max) {
        for (EditText et : inputs) {
            et.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
                @Override
                public void afterTextChanged(Editable s) {
                    String val = s.toString();
                    if (!val.isEmpty()) {
                        try {
                            int num = Integer.parseInt(val);
                            if (num < min || num > max) {
                                et.setError(min + " ile " + max + " arasında sayı girin");
                            } else {
                                et.setError(null);
                            }
                        } catch (NumberFormatException e) {
                            et.setError("Geçersiz sayı");
                        }
                    } else {
                        et.setError(null);
                    }
                }
            });
        }
    }

    private void addDraw() {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        android.content.ContentValues values = new android.content.ContentValues();

        for (int i = 0; i < numberInputs.length; i++) {
            String val = numberInputs[i].getText().toString().trim();
            if (val.isEmpty()) {
                Toast.makeText(this, "Tüm kutuları doldurun", Toast.LENGTH_SHORT).show();
                return;
            }
            int num;
            try {
                num = Integer.parseInt(val);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Geçersiz sayı", Toast.LENGTH_SHORT).show();
                return;
            }
            if (num < 1 || num > 80) {
                Toast.makeText(this, "1-80 arası sayı girin", Toast.LENGTH_SHORT).show();
                return;
            }
            values.put("n" + (i + 1), num);
        }

        long id = db.insert("on_numara", null, values);
        if (id > 0) {
            Toast.makeText(this, "Çekiliş kaydedildi", Toast.LENGTH_SHORT).show();
            for (EditText et : numberInputs) et.setText("");
        }
    }

    private void showMostCommonAnimated2() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM on_numara", null);

        Map<Integer, Integer> freq = new HashMap<>();

        while (cursor.moveToNext()) {
            for (int i = 1; i <= 10; i++) {
                int columnIndex = cursor.getColumnIndex("n" + i);
                if (columnIndex != -1) {
                    int num = cursor.getInt(columnIndex);
                    freq.put(num, freq.getOrDefault(num, 0) + 1);
                }
            }
        }
        cursor.close();

        List<Map.Entry<Integer, Integer>> sorted = new ArrayList<>(freq.entrySet());
        sorted.sort((a, b) -> b.getValue() - a.getValue());

        List<Integer> topNumbers = new ArrayList<>();
        for (int i = 0; i < Math.min(10, sorted.size()); i++) {
            topNumbers.add(sorted.get(i).getKey());
        }

        animateNumbers2(topNumbers);
    }

    private void animateNumbers2(List<Integer> numbers) {
        animatedNumbersContainer.removeAllViews();

        final int animationDuration = 600;

        TextView bigNumberView = new TextView(this);
        bigNumberView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 64);
        bigNumberView.setTextColor(Color.parseColor("#FF5722"));
        bigNumberView.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams bigParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        bigParams.setMarginEnd(24);
        bigNumberView.setLayoutParams(bigParams);

        animateNextNumber2(numbers, 0, bigNumberView, animationDuration);
    }

    private void animateNextNumber2(List<Integer> numbers, int index, TextView bigNumberView, int duration) {
        if (index >= numbers.size()) {
            animatedNumbersContainer.removeView(bigNumberView);
            return;
        }

        int number = numbers.get(index);
        bigNumberView.setText(String.valueOf(number));
        bigNumberView.setScaleX(0f);
        bigNumberView.setScaleY(0f);
        bigNumberView.setAlpha(0f);
        bigNumberView.setTranslationY(0f);

        if (bigNumberView.getParent() == null) {
            animatedNumbersContainer.addView(bigNumberView, 0);
        }

        bigNumberView.animate()
                .scaleX(1f).scaleY(1f)
                .alpha(1f)
                .setDuration(duration)
                .setListener(null)
                .withEndAction(() -> {
                    TextView smallNumber = new TextView(this);
                    smallNumber.setText(String.valueOf(number));
                    smallNumber.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
                    smallNumber.setTextColor(Color.WHITE);
                    smallNumber.setGravity(Gravity.CENTER);
                    smallNumber.setBackgroundResource(R.drawable.rounded_background);
                    smallNumber.setPadding(24, 16, 24, 16);

                    LinearLayout.LayoutParams smallParams = new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT);
                    smallParams.setMargins(12, 0, 12, 0);
                    smallNumber.setLayoutParams(smallParams);
                    smallNumber.setAlpha(0f);

                    animatedNumbersContainer.addView(smallNumber);

                    ObjectAnimator fadeIn = ObjectAnimator.ofFloat(smallNumber, "alpha", 0f, 1f);
                    fadeIn.setDuration(300);

                    AnimatorSet moveAndShrink = new AnimatorSet();
                    ObjectAnimator scaleX = ObjectAnimator.ofFloat(bigNumberView, "scaleX", 0.3f);
                    ObjectAnimator scaleY = ObjectAnimator.ofFloat(bigNumberView, "scaleY", 0.3f);
                    ObjectAnimator alpha = ObjectAnimator.ofFloat(bigNumberView, "alpha", 0f);
                    ObjectAnimator translateY = ObjectAnimator.ofFloat(bigNumberView, "translationY", 0f, 60f);

                    moveAndShrink.playTogether(scaleX, scaleY, alpha, translateY);
                    moveAndShrink.setDuration(400);

                    moveAndShrink.addListener(new AnimatorListenerAdapter() {
                        @Override
                        public void onAnimationEnd(Animator animation) {
                            animatedNumbersContainer.removeView(bigNumberView);
                            animateNextNumber2(numbers, index + 1, bigNumberView, duration);
                        }
                    });

                    fadeIn.start();
                    moveAndShrink.start();
                })
                .start();
    }
}
