package com.umka.lotoapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DatabaseHelper  extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "lotto_db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE sayisal_loto (id INTEGER PRIMARY KEY AUTOINCREMENT, n1 INT, n2 INT, n3 INT, n4 INT, n5 INT, n6 INT)");
        db.execSQL("CREATE TABLE super_loto (id INTEGER PRIMARY KEY AUTOINCREMENT, n1 INT, n2 INT, n3 INT, n4 INT, n5 INT, n6 INT)");
        db.execSQL("CREATE TABLE sans_topu (id INTEGER PRIMARY KEY AUTOINCREMENT, n1 INT, n2 INT, n3 INT, n4 INT, n5 INT, bonus INT)");
        db.execSQL("CREATE TABLE on_numara (id INTEGER PRIMARY KEY AUTOINCREMENT, n1 INT, n2 INT, n3 INT, n4 INT, n5 INT, n6 INT, n7 INT, n8 INT, n9 INT, n10 INT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS sayisal_loto");
        db.execSQL("DROP TABLE IF EXISTS super_loto");
        db.execSQL("DROP TABLE IF EXISTS sans_topu");
        db.execSQL("DROP TABLE IF EXISTS on_numara");
        onCreate(db);
    }
}
