package com.umka.lotoapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    Button btnCilgin, btnSuper, btnSans, btnOnNumara,btnGecmisVeriler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        btnCilgin = findViewById(R.id.btnSayisalLoto);
        btnSuper = findViewById(R.id.btnSuperLoto);
        btnSans = findViewById(R.id.btnSansTopu);
        btnOnNumara = findViewById(R.id.btnOnNumara);
        btnGecmisVeriler = findViewById(R.id.btnGecmisVeriler);

        btnCilgin.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CilginLoto.class);
            startActivity(intent);
        });

        btnSuper.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SuperLotto.class);
            startActivity(intent);
        });

        btnSans.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SansTopu.class);
            startActivity(intent);
        });

        btnOnNumara.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, OnNumara.class);
            startActivity(intent);
        });
        btnGecmisVeriler.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, HistoryActivity.class));
        });

    }
}