package com.umka.lotoapp;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HistoryDetailActivity extends AppCompatActivity {

    public static final String EXTRA_GAME = "game";

    private DatabaseHelper dbHelper;
    private LinearLayout containerLayout;
    private LinearLayout numbersContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scrollView = new ScrollView(this);
        containerLayout = new LinearLayout(this);
        containerLayout.setOrientation(LinearLayout.VERTICAL);
        containerLayout.setPadding(24, 24, 24, 24);
        scrollView.addView(containerLayout);

        setContentView(scrollView);

        dbHelper = new DatabaseHelper(this);

        String game = getIntent().getStringExtra(EXTRA_GAME);
        if (game == null) {
            finish();
            return;
        }

        // Başlık
        TextView titleView = new TextView(this);
        titleView.setText(getGameTitle(game) + " Geçmiş Verileri");
        titleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        titleView.setTypeface(null, Typeface.BOLD);
        titleView.setTextColor(Color.parseColor("#3F51B5"));
        titleView.setGravity(Gravity.CENTER);
        titleView.setPadding(0, 0, 0, 24);
        containerLayout.addView(titleView);

        TextView subtitleView = new TextView(this);
        subtitleView.setText(getSubtitleText(game));
        subtitleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        subtitleView.setTextColor(Color.DKGRAY);
        subtitleView.setGravity(Gravity.CENTER);
        subtitleView.setPadding(0, 0, 0, 24);
        containerLayout.addView(subtitleView);

        numbersContainer = new LinearLayout(this);
        numbersContainer.setOrientation(LinearLayout.VERTICAL);
        containerLayout.addView(numbersContainer);

        showHistory(game);
    }

    private String getGameTitle(String game) {
        switch (game) {
            case "cilgin": return "Çılgın Loto";
            case "super": return "Süper Loto";
            case "sans": return "Şans Topu";
            case "onnumara": return "On Numara";
            default: return "Loto";
        }
    }

    private String getSubtitleText(String game) {
        switch (game) {
            case "cilgin": return "1-90 arası Sayılar ve kaç kez tekrarlandığı";
            case "super": return "1-60 arası Sayılar ve kaç kez tekrarlandığı";
            case "sans": return "1-34 arası Sayılar ve kaç kez tekrarlandığı (bonus: 1-14 arası)";
            case "onnumara": return "1-80 arası Sayılar ve kaç kez tekrarlandığı";
            default: return "Sayılar ve kaç kez tekrarlandığı";
        }
    }

    private void showHistory(String game) {
        String tableName;
        int numberCount;

        Map<Integer, Integer> freqMain = new HashMap<>();
        Map<Integer, Integer> freqBonus = new HashMap<>();

        switch (game) {
            case "cilgin": tableName = "sayisal_loto"; numberCount = 6; break;
            case "super": tableName = "super_loto"; numberCount = 6; break;
            case "sans": tableName = "sans_topu"; numberCount = 5; break;
            case "onnumara": tableName = "on_numara"; numberCount = 10; break;
            default: finish(); return;
        }

        try (var db = dbHelper.getReadableDatabase();
             var cursor = db.rawQuery("SELECT * FROM " + tableName, null)) {

            while (cursor.moveToNext()) {
                for (int i = 1; i <= numberCount; i++) {
                    int colIndex = cursor.getColumnIndex("n" + i);
                    if (colIndex != -1) {
                        int num = cursor.getInt(colIndex);
                        freqMain.put(num, freqMain.getOrDefault(num, 0) + 1);
                    }
                }
                if (game.equals("sans")) {
                    int bonusIndex = cursor.getColumnIndex("bonus");
                    if (bonusIndex != -1) {
                        int bonusNum = cursor.getInt(bonusIndex);
                        freqBonus.put(bonusNum, freqBonus.getOrDefault(bonusNum, 0) + 1);
                    }
                }
            }
        }

        if (freqMain.isEmpty() && freqBonus.isEmpty()) {
            addMessage("Veritabanında veri bulunamadı.");
            return;
        }

        if (game.equals("sans")) {
            showAnimatedSeparatedNumbers(freqMain, freqBonus);
        } else {
            List<Map.Entry<Integer, Integer>> sorted = new ArrayList<>(freqMain.entrySet());
            Collections.sort(sorted, (a, b) -> b.getValue() - a.getValue());
            addNumbersWithAnimation(sorted);
        }
    }

    private void addMessage(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        tv.setTextColor(Color.DKGRAY);
        tv.setPadding(0, 8, 0, 8);
        numbersContainer.addView(tv);
    }


    private void showAnimatedSeparatedNumbers(Map<Integer, Integer> freqMain, Map<Integer, Integer> freqBonus) {
        numbersContainer.removeAllViews();


        TextView mainTitle = new TextView(this);
        mainTitle.setText("Ana Sayılar");
        mainTitle.setTextSize(18);
        mainTitle.setTypeface(null, Typeface.BOLD);
        mainTitle.setTextColor(Color.BLACK);
        mainTitle.setGravity(Gravity.CENTER);
        mainTitle.setPadding(0, 0, 0, 16);
        numbersContainer.addView(mainTitle);

        List<Map.Entry<Integer, Integer>> mainList = new ArrayList<>(freqMain.entrySet());
        Collections.sort(mainList, (a, b) -> b.getValue() - a.getValue());
        addNumbersWithAnimation(mainList);

        // Bonus sayılar başlığı
        TextView bonusTitle = new TextView(this);
        bonusTitle.setText("Bonus Sayılar");
        bonusTitle.setTextSize(18);
        bonusTitle.setTypeface(null, Typeface.BOLD);
        bonusTitle.setTextColor(Color.BLACK);
        bonusTitle.setGravity(Gravity.CENTER);
        bonusTitle.setPadding(0, 24, 0, 16);
        numbersContainer.addView(bonusTitle);

        List<Map.Entry<Integer, Integer>> bonusList = new ArrayList<>(freqBonus.entrySet());
        Collections.sort(bonusList, (a, b) -> b.getValue() - a.getValue());
        addNumbersWithAnimation(bonusList);
    }


    private void addNumbersWithAnimation(List<Map.Entry<Integer, Integer>> sortedNumbers) {
        int delay = 0;
        int delayIncrement = 150;

        LinearLayout rowLayout = null;
        int itemsInRow = 0;
        int maxItemsPerRow = 2;

        for (Map.Entry<Integer, Integer> entry : sortedNumbers) {
            if (itemsInRow == 0) {
                rowLayout = new LinearLayout(this);
                rowLayout.setOrientation(LinearLayout.HORIZONTAL);
                LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);
                rowParams.setMargins(0, 0, 0, 12);
                rowLayout.setLayoutParams(rowParams);
                numbersContainer.addView(rowLayout);
            }

            int number = entry.getKey();
            int count = entry.getValue();

            LinearLayout itemLayout = new LinearLayout(this);
            itemLayout.setOrientation(LinearLayout.VERTICAL);
            itemLayout.setPadding(16, 12, 16, 12);
            itemLayout.setBackgroundColor(Color.parseColor("#E8EAF6"));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            params.setMargins(8, 0, 8, 0);
            itemLayout.setLayoutParams(params);
            itemLayout.setElevation(4f);
            itemLayout.setTranslationY(30f);
            itemLayout.setAlpha(0f);

            TextView numberView = new TextView(this);
            numberView.setText(String.valueOf(number));
            numberView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
            numberView.setTypeface(null, Typeface.BOLD);
            numberView.setTextColor(Color.parseColor("#3F51B5"));
            numberView.setGravity(Gravity.CENTER_HORIZONTAL);
            numberView.setPadding(0, 0, 0, 4);

            TextView countView = new TextView(this);
            countView.setText(count + " kez");
            countView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            countView.setTextColor(Color.parseColor("#303F9F"));
            countView.setGravity(Gravity.CENTER_HORIZONTAL);

            itemLayout.addView(numberView);
            itemLayout.addView(countView);

            if (rowLayout != null) {
                rowLayout.addView(itemLayout);
            }


            ObjectAnimator animY = ObjectAnimator.ofFloat(itemLayout, "translationY", 30f, 0f);
            ObjectAnimator animAlpha = ObjectAnimator.ofFloat(itemLayout, "alpha", 0f, 1f);
            AnimatorSet animatorSet = new AnimatorSet();
            animatorSet.playTogether(animY, animAlpha);
            animatorSet.setStartDelay(delay);
            animatorSet.setDuration(300);
            animatorSet.start();

            delay += delayIncrement;

            itemsInRow++;
            if (itemsInRow == maxItemsPerRow) {
                itemsInRow = 0;
            }
        }
    }
}
