package com.umka.lotoapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class HistoryActivity extends AppCompatActivity {

    Button btnCilginHistory, btnSuperHistory, btnSansHistory, btnOnNumaraHistory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_history);

        btnCilginHistory = findViewById(R.id.btnCilginHistory);
        btnSuperHistory = findViewById(R.id.btnSuperHistory);
        btnSansHistory = findViewById(R.id.btnSansHistory);
        btnOnNumaraHistory = findViewById(R.id.btnOnNumaraHistory);

        btnCilginHistory.setOnClickListener(v -> {
            Intent intent = new Intent(this, HistoryDetailActivity.class);
            intent.putExtra("game", "cilgin");
            startActivity(intent);
        });

        btnSuperHistory.setOnClickListener(v -> {
            Intent intent = new Intent(this, HistoryDetailActivity.class);
            intent.putExtra("game", "super");
            startActivity(intent);
        });

        btnSansHistory.setOnClickListener(v -> {
            Intent intent = new Intent(this, HistoryDetailActivity.class);
            intent.putExtra("game", "sans");
            startActivity(intent);
        });

        btnOnNumaraHistory.setOnClickListener(v -> {
            Intent intent = new Intent(this, HistoryDetailActivity.class);
            intent.putExtra("game", "onnumara");
            startActivity(intent);
        });
    }
}
